//
//  NotiView.swift
//  test
//
//  Created by Alpaca on 2017. 2. 15..
//  Copyright © 2017년 LEOFALCON. All rights reserved.
//

import UIKit

class NotiView: UIView {
    @IBOutlet weak var label: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
}
    override
