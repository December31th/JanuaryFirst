//
//  CellView.swift
//  test
//
//  Created by LEOFALCON on 2017. 1. 24..
//  Copyright © 2017년 LEOFALCON. All rights reserved.
//

import Foundation
import JTAppleCalendar
import AKPickerView_Swift

class CellView: JTAppleDayCellView {
    @IBOutlet var dayLabel: UILabel!
    @IBOutlet var selectedView: UIView!
    @IBOutlet var goal1: UIView!
    @IBOutlet var goal2: UIView!
    @IBOutlet var goal3: UIView!

    
}

